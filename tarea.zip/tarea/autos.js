let autos=[
    {
        marca:'Ford',
        modelo:'Fiesta',
        anio:2019,
        precio:150000,
        color:'azul',
        cuotas:12,
        km:200,
        patente:'APL123',
        vendido:false

    },
    {
        marca:'Toyota',
        modelo:'Corola',
        anio:2019,
        precio:100000,
        color:'blanco',
        cuotas:14,
        km:0,
        patente:'JJK116',
        vendido:false
    }
]
module.exports=autos;